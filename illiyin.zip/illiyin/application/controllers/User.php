<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	 function __construct(){
     parent::__construct();

    //  $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
    //  $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    //  $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
    //  $this->output->set_header('Pragma: no-cache');
     $this->load->helper('url');
     $this->load->model('U_Model');
     $this->load->library('session');
     $this->load->helper('form');
   }
   
   public function index()
   {       
    $this->load->view('login');
   }

   public function error()
   {
    $this->load->view('error404.php'); 
   }
   public function filter($data)
   {	$data = preg_replace('/[^a-zA-Z0-9]/', '', $data);
     return $data;
     unset($data);
   }
   public function ceklogin()
   {
     if(isset($_POST['login'])){
       $users = $this->input->post('username',true);
       $users = $this->filter($users);
       $pass = $this->input->post('password',true);
       $pass = $this->filter($pass);
       $cek = $this->U_Model->proseslogin($users,$pass);
       $hasil = count($cek);
       if($hasil > 0){
         $pelogin = $this->db->get_where('user',array('username' => $users, 'password' => $pass))->row();
         if($pelogin->level == 'admin'){
           $sdata=array();
           $sdata['username']= $cek->username;
           $sdata['password']= $cek->password;
           $this->session->set_userdata($sdata);
           if ( $this->session->userdata('username') and 
              $this->session->userdata('password') )
          {	redirect('user/admin');
          } else
          {	$this->load->view('login');
          }
         }elseif($pelogin->level == 'pimpinan'){
            $sdata=array();
            $sdata['username']= $cek->username;
            $sdata['password']= $cek->password;
            $this->session->set_userdata($sdata);
            if ( $this->session->userdata('username') and 
            $this->session->userdata('password') )
            {	redirect('user/pimpinan');
            } else
            {	$this->load->view('login');
            }
         }
       }else{
          redirect('user/login_gagal');
       }
       unset($users,$pass,$cek,$hasil,$sdata);
     }
   }
   public function login_gagal()
   {	$data['gagal'] = 'Anda Gagal Login';
     $this->load->view('login',$data);		
   }

   //Bagian CRUD profil admin

   public function update( $id = NULL )
   {
     $this->db->where('id', $id);
     $data['content'] = $this->db->get('user');
 
     $this->load->view('admin/update', $data);
   }

   public function action_update($id ='')
   {
     $data['name'] = $this->input->post('name');
     $data['masjid'] = $this->input->post('masjid');
     $data['username'] = $this->input->post('username');
     $data['password'] = $this->input->post('password');
     $data['level'] = $this->input->post('level');
     
     $this->db->where('id', $id);
     $this->db->update('user', $data);
 
     redirect('user/profil','refresh');
   }

   public function delete( $id = NULL )
   {
     $this->db->where('id', $id);
     $this->db->delete('user');
 
     redirect('user/profil','refresh');
   }

   //Delete comment admin

   public function delete_comment( $name = NULL )
   {
     $this->db->where('name', $name);
     $this->db->delete('comment');
 
     redirect('user/admin','refresh');
   }

   public function delete_comment2( $name = NULL )
   {
     $this->db->where('name', $name);
     $this->db->delete('comment2');
 
     redirect('user/article','refresh');
   }

   public function login()
   {
     $this->load->view('login');
   }

   public function logout()
   {
     $username=$this->session->userdata('username');
     $password=$this->session->userdata('password');
     $array_items = array($username => '', $password => '');
     $this->session->unset_userdata($array_items);
     $this->session->sess_destroy();
     redirect('user/index');
   }

   //Halaman Admin

   public function admin()
   {
     $data['data']=$this->U_Model->get_data_stok();
     $data['data2']=$this->U_Model->get_data_stok2();
     $data['data3']=$this->U_Model->get_data_stok3();
     
     $this->load->view('admin/index', $data);
   }
   
   public function print_data($bulan = NULL)
   {
     $this->db->where('bulan', $bulan);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT `bulan`,SUM(`harga_beli`) AS `harga_beli` FROM barang WHERE `bulan`='$bulan'");
     
     $this->load->view('admin/print', $data);
   }

   public function print_data2($tahun = NULL)
   {
     $this->db->where('tahun', $tahun);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT `tahun`,SUM(`harga_beli`) AS `harga_beli` FROM barang WHERE `tahun`='$tahun'");
     
     $this->load->view('admin/print2', $data);
   }

   public function print_data3($bulan = NULL)
   {
     $this->db->where('bulan', $bulan);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT SUM(CASE WHEN status='Baik' then jumlah else 0 end) as Baik ,
     SUM(CASE WHEN status='Buruk' then jumlah else 0 end) as Buruk ,
     bulan from barang where `bulan`='$bulan'");
     
     $this->load->view('admin/print3', $data);
   }
  
   public function barang()
   {
    $data['content'] = $this->db->query("SELECT * FROM barang ORDER BY `id` DESC");
    $data['content2']=$this->db->query("SELECT `bulan`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `bulan` ORDER BY `tahun`");
    $data['content3']=$this->db->query("SELECT `tahun`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `tahun` ORDER BY `tahun`");
    $data['content4']=$this->db->query("SELECT SUM(CASE WHEN status='Baik' then jumlah else 0 end) as Baik ,
    SUM(CASE WHEN status='Buruk' then jumlah else 0 end) as Buruk ,
    bulan from barang group by bulan order by tahun");
    $this->load->view('admin/barang', $data);
   }

   public function kategori()
   {
    $data['content'] = $this->db->get('kategori_barang'); 
    $this->load->view('admin/kategori_barang', $data);
   }

   public function create_kategori()
   {
    $this->load->view('admin/create_kategori');
   }

   public function proseskategoribarang()
   {
    $nama=$this->input->post('nama');
    
    if($_POST['submit']){
      $data=array(
        'nama'=>$nama
      );   
      $this->U_Model->input_kategori_barang($data,'kategori');;
      redirect('user/kategori','refresh');
    }
   }

   public function delete_kategori($id=NULL)
   {
    if(empty($id)) show_404();

    if($this->U_Model->delete_kategori($id)){
      redirect(site_url('user/kategori'));
    }
  }

   public function edit_kategori( $id = NULL )
   {
     $this->db->where('id', $id);
     $data['content'] = $this->db->get('kategori_barang');
 
     $this->load->view('admin/edit_kategori', $data);
   }

   public function proses_edit_kategori_barang($id ='')
   {
     $nama=$this->input->post('nama');

     if($_POST['submit']){
      $data=array(
        'nama'=>$nama
      );

        $this->db->where('id', $id);
        $this->db->update('kategori_barang', $data);
        redirect('user/kategori','refresh');
    }
   }

   public function user()
   {
    $data['content'] = $this->db->get('user');
    $this->load->view('admin/user', $data);
   }

   public function create_barang()
   {
     $data['content'] = $this->db->get('kategori_barang');
     $this->load->view('admin/create_barang',$data);
   } 

   public function prosesbarang()
   {
    $nama=$this->input->post('nama');
    $produsen=$this->input->post('produsen');
    $jumlah=$this->input->post('jumlah');
    $harga_beli=$this->input->post('harga_beli');
    $tanggal_beli=$this->input->post('tanggal_beli');
    $tanggal_produksi=$this->input->post('tanggal_produksi');
    $kategori=$this->input->post('kategori');
    $status=$this->input->post('status');
    $gambar=$_FILES['gambar']['name'];
    $bulan=$this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    
    if($_POST['submit']){
      $config['upload_path']='./data';
      $config['allowed_types']='jpg|gif|png|jpeg';

      $this->load->library('upload',$config);
      if(!$this->upload->do_upload('gambar')){
       echo "upload gambar gagal";
      }
      else{
        $gambar=$this->upload->data('file_name');
      }

      $data=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'kategori'=>$kategori,
        'status'=>$status,
        'gambar'=>$gambar,
        'bulan'=>$bulan,
        'tahun'=>$tahun
      );   
      $this->U_Model->input_barang($data,'barang');;
      redirect('user/barang','refresh');
    }else{
      redirect('admin/index');
     }
   }

   public function detail_barang( $id = NULL )
   {
    $this->db->where('id', $id);
    $data['content'] = $this->db->get('barang');
    $this->load->view('admin/detail_barang', $data);
   }

   public function delete_barang($id=NULL)
   {
    if(empty($id)) show_404();

    if($this->U_Model->delete($id)){
      redirect(site_url('user/barang'));
    }
  }
   
   public function edit_barang( $id = NULL )
   {
     $this->db->where('id', $id);
     $data['content'] = $this->db->get('barang');
     $data['content2'] = $this->db->get('kategori_barang');
 
     $this->load->view('admin/edit_barang', $data);
   }

   public function proses_edit_barang($id ='')
   {
     $nama=$this->input->post('nama');
     $produsen=$this->input->post('produsen');
     $jumlah=$this->input->post('jumlah');
     $harga_beli=$this->input->post('harga_beli');
     $tanggal_beli=$this->input->post('tanggal_beli');
     $tanggal_produksi=$this->input->post('tanggal_produksi');
     $kategori=$this->input->post('kategori');
     $status=$this->input->post('status');
     $gambar=$_FILES['gambar']['name'];

     if($_POST['submit']){
      $config['upload_path']='./data';
      $config['allowed_types']='jpg|gif|png|jpeg';

      $this->load->library('upload',$config);
      if(!$this->upload->do_upload('gambar')){
      }
      else{
        $gambar=$this->upload->data('file_name');
      }

      $data=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi
      );
      $data2=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'status'=>$status
      );
      $data3=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'kategori'=>$kategori
      );
      $data4=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'gambar'=>$gambar
      );
      $data5=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'status'=>$status,
        'gambar'=>$gambar
      );
      $data6=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'kategori'=>$kategori,
        'gambar'=>$gambar
      );
      $data7=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'kategori'=>$kategori,
        'status'=>$status
      );
      $data8=array(
        'nama'=>$nama,
        'produsen'=>$produsen,
        'jumlah'=>$jumlah,
        'harga_beli'=>$harga_beli,
        'tanggal_beli'=>$tanggal_beli,
        'tanggal_produksi'=>$tanggal_produksi,
        'kategori'=>$kategori,
        'status'=>$status,
        'gambar'=>$gambar
      );

      if($kategori=="Pilih Kategori" and $status=="Pilih Status" and $gambar==''){
        $this->db->where('id', $id);
        $this->db->update('barang', $data);
        redirect('user/barang','refresh');
      }elseif($kategori=="Pilih Kategori" and $gambar==''){
        $this->db->where('id', $id);
        $this->db->update('barang', $data2);
        redirect('user/barang','refresh');
      }elseif($status=="Pilih Status" and $gambar==''){
        $this->db->where('id', $id);
        $this->db->update('barang', $data3);
        redirect('user/barang','refresh');
      }elseif($status=="Pilih Status" and $kategori=="Pilih Kategori"){
        $this->db->where('id', $id);
        $this->db->update('barang', $data4);
        redirect('user/barang','refresh');
      }elseif($kategori=="Pilih Kategori"){
        $this->db->where('id', $id);
        $this->db->update('barang', $data5);
        redirect('user/barang','refresh');
      }elseif($status=="Pilih Status"){
        $this->db->where('id', $id);
        $this->db->update('barang', $data6);
        redirect('user/barang','refresh');
      }elseif($gambar==''){
        $this->db->where('id', $id);
        $this->db->update('barang', $data7);
        redirect('user/barang','refresh');
      }else{
        $this->db->where('id', $id);
        $this->db->update('barang', $data8);
        redirect('user/barang','refresh');
      }
    }else{
      redirect('admin/index');
     }
   }

   public function detail_user( $id = NULL )
   {
    $this->db->where('id', $id);
    $data['content'] = $this->db->get('user');
    $this->load->view('admin/detail_user', $data);
   }

   public function delete_user($id=NULL)
   {
    if(empty($id)) show_404();

    if($this->U_Model->delete_user($id)){
      redirect(site_url('user/user'));
    }
  }

   public function create_user()
   {
     $this->load->view('admin/create_user');
   } 

   public function prosesuser()
   {
    $this->U_Model->create_user();
    redirect('user/user','refresh');
   }

   public function edit_user( $id = NULL )
   {
     $this->db->where('id', $id);
     $data['content'] = $this->db->get('user');
 
     $this->load->view('admin/edit_user', $data);
   }

   public function proses_edit_user($id ='')
   {
     $username=$this->input->post('username');
     $password=$this->input->post('password');
     $level=$this->input->post('level');

     $data=array(
      'username'=>$username,
      'password'=>$password,
      'level'=>$level
     );

     $this->db->where('id', $id);
     $this->db->update('user', $data);
 
     redirect('user/user','refresh');
   }

   //BAGIAN PIMPINAN

   public function pimpinan()
   {
     //  $data['data']=$this->U_Model->get_barang();
     $data['data']=$this->U_Model->get_data_stok();
     $data['data2']=$this->U_Model->get_data_stok2();
     $data['data3']=$this->U_Model->get_data_stok3();
     
     $this->load->view('pimpinan/index', $data);
   }

   public function barang_pimpinan()
   {
     $data['content'] = $this->db->get('barang');
     $data['content2']=$this->db->query("SELECT `bulan`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `bulan` ORDER BY `tahun`");
     $data['content3']=$this->db->query("SELECT `tahun`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `tahun` ORDER BY `tahun`");
     $data['content4']=$this->db->query("SELECT SUM(CASE WHEN status='Baik' then jumlah else 0 end) as Baik ,
     SUM(CASE WHEN status='Buruk' then jumlah else 0 end) as Buruk ,
     bulan from barang group by bulan order by tahun");

     $this->load->view('pimpinan/barang', $data);
   }

   public function detail_barang_pimpinan( $id = NULL )
   {
    $this->db->where('id', $id);
    $data['content'] = $this->db->get('barang');
    $this->load->view('pimpinan/detail_barang', $data);
   }

   public function print_data_pimpinan($bulan = NULL)
   {
     $this->db->where('bulan', $bulan);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT `bulan`,SUM(`harga_beli`) AS `harga_beli` FROM barang WHERE `bulan`='$bulan'");
     
     $this->load->view('pimpinan/print', $data);
   }

   public function print_data_pimpinan2($tahun = NULL)
   {
     $this->db->where('tahun', $tahun);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT `tahun`,SUM(`harga_beli`) AS `harga_beli` FROM barang WHERE `tahun`='$tahun'");
     
     $this->load->view('pimpinan/print2', $data);
   }

   public function print_data_pimpinan3($bulan = NULL)
   {
     $this->db->where('bulan', $bulan);
     $data['content']=$this->db->get('barang');
     $data['content2']=$this->db->query("SELECT SUM(CASE WHEN status='Baik' then jumlah else 0 end) as Baik ,
     SUM(CASE WHEN status='Buruk' then jumlah else 0 end) as Buruk ,
     bulan from barang where `bulan`='$bulan'");
     
     $this->load->view('pimpinan/print3', $data);
   }
}

  
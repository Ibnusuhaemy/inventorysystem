<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>
      Page Error 404
    </title>
  </head>
  <style>
    .error-page img{
      width:100%;
    }
  </style>
  <body>
    <div class="error-page">
      <img src="<?php echo base_url(); ?>assets/error/errors.jpg" alt="error">
    </div>
  </body>
</html>
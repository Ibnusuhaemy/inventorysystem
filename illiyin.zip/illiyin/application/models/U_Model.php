<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class U_Model extends CI_Model {

   public function proseslogin($users,$pass)
   {
     $this->db->where('username', $users);
     $this->db->where('password',$pass);
     return $this->db->get('user')->row();
   }

   public function input_barang($data)
   {
    $this->db->insert('barang', $data);
   }

   public function input_kategori_barang($data)
   {
    $this->db->insert('kategori_barang', $data);
   }

   public function delete($id)
   {
     return $this->db->delete('barang',array('id'=>$id));
   }

   public function delete_user($id)
   {
     return $this->db->delete('user',array('id'=>$id));
   }

   public function delete_kategori($id)
   {
     return $this->db->delete('kategori_barang',array('id'=>$id));
   }

   function get_data_stok(){
    $query = $this->db->query("SELECT `bulan`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `bulan` ORDER BY `tahun`");
      
    if($query->num_rows() > 0){
      foreach($query->result() as $data){
          $hasil[] = $data;
      }
      return $hasil;
    }
  }
  function get_data_stok2(){
    $query = $this->db->query("SELECT `tahun`,SUM(`harga_beli`) AS `harga_beli` FROM barang GROUP BY `tahun` ORDER BY `tahun`");
      
    if($query->num_rows() > 0){
      foreach($query->result() as $data){
          $hasil[] = $data;
      }
      return $hasil;
    }
  }
  function get_data_stok3(){
    $query = $this->db->query("SELECT SUM(CASE WHEN status='Baik' then jumlah else 0 end) as Baik ,
    SUM(CASE WHEN status='Buruk' then jumlah else 0 end) as Buruk ,
    bulan from barang group by bulan order by tahun");
    
    if($query->num_rows() > 0){
      foreach($query->result() as $data){
          $hasil[] = $data;
      }
      return $hasil;
    }
  }

  public function create_user()
  {
    $data = array('username' => $this->input->post('username'),
    'password' => $this->input->post('password'),
    'level' => $this->input->post('level'));
    $query = $this->db->insert('user',$data);
    return $query;
  }
 
  function get_barang(){
    $query = $this->db->query("SELECT * FROM barang");
    
    return $query;
    }
  
}

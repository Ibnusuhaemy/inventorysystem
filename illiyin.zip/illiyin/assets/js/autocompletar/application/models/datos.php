<?php
/**
* 
*/
class Datos extends CI_Model
{

}